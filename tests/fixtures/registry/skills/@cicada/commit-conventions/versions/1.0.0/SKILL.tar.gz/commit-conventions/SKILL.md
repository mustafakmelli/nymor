---
name: Commit Conventions
description: Registry fixture skill.
globs:
  - "**/*"
alwaysApply: true
---

# Skill: Commit Conventions

## Rule
Use conventional commits.

## Why
Consistent history is easier to scan.

## Example
feat(cli): add registry install
